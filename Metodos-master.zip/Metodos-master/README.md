#@Disciplina: Metodos Numéricos
#@Autor: Natanael Moreira

Códigos de Métodos numéricos

#Algumas implementações sobre métodos para a resoluçao de sistemas de equações lineares com variações de métodos 
iterativos e métodos diretos.
